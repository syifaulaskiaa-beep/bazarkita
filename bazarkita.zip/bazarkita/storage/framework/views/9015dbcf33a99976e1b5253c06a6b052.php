

<?php $__env->startSection('content'); ?>
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="font-judul text-3xl font-bold text-tinta">Periksa Pendaftaran</h1>
            <p class="text-gray-500 mt-1">Kelola dan tinjau pendaftaran tenant untuk setiap event.</p>
        </div>
    </div>

    <?php if(session('sukses')): ?> <div class="bg-green-50 border-l-4 border-green-500 text-green-700 p-4 rounded mb-6 shadow-sm"><?php echo e(session('sukses')); ?></div> <?php endif; ?>
    <?php if(session('error')): ?> <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 rounded mb-6 shadow-sm"><?php echo e(session('error')); ?></div> <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-gray-50 border-b border-gray-100">
                    <tr>
                        <th class="p-5 font-semibold text-sm text-gray-600">Nama Usaha</th>
                        <th class="p-5 font-semibold text-sm text-gray-600">Event</th>
                        <th class="p-5 font-semibold text-sm text-gray-600">Booth</th>
                        <th class="p-5 font-semibold text-sm text-gray-600">Status</th>
                        <th class="p-5 font-semibold text-sm text-gray-600 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 transition duration-150">
                        <td class="p-5">
                            <div class="font-bold text-tinta"><?php echo e($p->tenant->nama_usaha ?? '-'); ?></div>
                            <div class="text-xs text-gray-500 mt-1"><?php echo e($p->tenant->user->name ?? '-'); ?></div>
                        </td>
                        <td class="p-5 text-sm text-gray-700"><?php echo e($p->event->nama_event ?? '-'); ?></td>
                        <td class="p-5 text-sm font-semibold text-gray-700"><?php echo e($p->booth->kode_booth ?? '-'); ?></td>
                        <td class="p-5">
                            <?php if($p->status == 'menunggu'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-yellow-100 text-yellow-800">
                                    <span class="w-2 h-2 rounded-full bg-yellow-500 mr-2"></span> Menunggu
                                </span>
                            <?php elseif($p->status == 'disetujui'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-green-100 text-green-800">
                                    <span class="w-2 h-2 rounded-full bg-green-500 mr-2"></span> Disetujui
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800">
                                    <span class="w-2 h-2 rounded-full bg-red-500 mr-2"></span> Ditolak
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="p-5 text-right">
                            <?php if($p->status == 'menunggu'): ?>
                            <form method="POST" action="<?php echo e(route('admin.setujui', $p->id_pendaftaran)); ?>" class="flex items-center justify-end space-x-2">
                                <?php echo csrf_field(); ?>
                                <select name="id_booth" class="border border-gray-300 rounded-lg p-2 text-sm focus:ring-emas focus:border-emas" required>
                                    <option value="">Pilih Booth</option>
                                    <?php $__currentLoopData = $p->event->booth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($booth->status == 'tersedia'): ?>
                                            <option value="<?php echo e($booth->id_booth); ?>"><?php echo e($booth->kode_booth); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button class="bg-tinta text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-800 transition shadow-sm">Setujui</button>
                            </form>
                            <?php else: ?>
                                <span class="text-gray-400 text-sm">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="p-12 text-center text-gray-500">
                            <svg class="w-12 h-12 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
                            Belum ada data pendaftaran.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bazarkita\resources\views/admin/pendaftaran.blade.php ENDPATH**/ ?>