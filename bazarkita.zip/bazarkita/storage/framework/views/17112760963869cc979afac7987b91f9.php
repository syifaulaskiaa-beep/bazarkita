

<?php $__env->startSection('content'); ?>
    <div class="flex justify-between items-center mb-6">
        <h1 class="font-judul text-2xl font-bold">Laporan</h1>
        <a href="<?php echo e(route('admin.laporan.csv')); ?>" class="bg-emas text-tinta px-4 py-2 rounded-lg font-bold hover:bg-yellow-500 transition">
            Download Laporan (CSV)
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-50 border-b border-gray-100">
                <tr>
                    <th class="p-4 font-semibold text-sm">Nama Usaha</th>
                    <th class="p-4 font-semibold text-sm">Event</th>
                    <th class="p-4 font-semibold text-sm">Booth</th>
                    <th class="p-4 font-semibold text-sm">Status Pendaftaran</th>
                    <th class="p-4 font-semibold text-sm">Status Bayar</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="p-4"><?php echo e($p->tenant->nama_usaha ?? '-'); ?></td>
                    <td class="p-4"><?php echo e($p->event->nama_event ?? '-'); ?></td>
                    <td class="p-4"><?php echo e($p->booth->kode_booth ?? '-'); ?></td>
                    <td class="p-4"><?php echo e($p->status); ?></td>
                    <td class="p-4"><?php echo e($p->pembayaran->status ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="p-8 text-center text-gray-500">Belum ada data pendaftaran.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bazarkita\resources\views/admin/laporan.blade.php ENDPATH**/ ?>