

<?php $__env->startSection('content'); ?>
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="font-judul text-2xl font-bold">Denah Booth</h1>
            <p class="text-gray-500 text-sm"><?php echo e($event->nama_event); ?></p>
        </div>
        <div class="flex space-x-4 text-sm">
            <div class="flex items-center"><span class="w-4 h-4 bg-green-500 rounded mr-2"></span> Tersedia</div>
            <div class="flex items-center"><span class="w-4 h-4 bg-red-500 rounded mr-2"></span> Terisi</div>
        </div>
    </div>

    <div class="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <?php $__currentLoopData = ['A', 'B', 'C']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <h3 class="font-bold text-lg mb-4 text-center border-b pb-2">Zona <?php echo e($zona); ?></h3>
                    <div class="grid grid-cols-2 gap-3">
                        <?php $__currentLoopData = $booths->where('zona', $zona); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-4 rounded-lg text-center font-bold text-white shadow-sm 
                                <?php echo e($booth->status == 'tersedia' ? 'bg-green-500' : 'bg-red-500'); ?>">
                                <?php echo e($booth->kode_booth); ?>

                                <div class="text-xs font-normal mt-1 opacity-80">
                                    <?php echo e($booth->status == 'tersedia' ? 'Kosong' : 'Terisi'); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bazarkita\resources\views/admin/denah-booth.blade.php ENDPATH**/ ?>