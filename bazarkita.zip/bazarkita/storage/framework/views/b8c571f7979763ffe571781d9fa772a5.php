

<?php $__env->startSection('content'); ?>
    <h1 class="font-judul text-2xl font-bold mb-6">Log Aktivitas</h1>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-50 border-b border-gray-100">
                <tr>
                    <th class="p-4 font-semibold text-sm">Waktu</th>
                    <th class="p-4 font-semibold text-sm">Admin</th>
                    <th class="p-4 font-semibold text-sm">Aksi</th>
                    <th class="p-4 font-semibold text-sm">Deskripsi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="p-4 text-sm text-gray-500"><?php echo e($log->created_at->format('d M Y, H:i')); ?></td>
                    <td class="p-4"><?php echo e($log->user->name ?? '-'); ?></td>
                    <td class="p-4">
                        <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-bold"><?php echo e($log->aksi); ?></span>
                    </td>
                    <td class="p-4 text-sm"><?php echo e($log->deskripsi); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="p-8 text-center text-gray-500">Belum ada aktivitas yang tercatat.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bazarkita\resources\views/admin/log.blade.php ENDPATH**/ ?>